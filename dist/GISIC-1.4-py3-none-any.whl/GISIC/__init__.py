from .spectrum import Spectrum
from .norm_functions import in_molecular_band
from .segment import Segment
from .normalize import normalize
